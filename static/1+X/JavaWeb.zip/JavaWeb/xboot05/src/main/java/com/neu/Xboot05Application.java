package com.neu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
public class Xboot05Application {

	public static void main(String[] args) {
		SpringApplication.run(Xboot05Application.class, args);
	}

}
