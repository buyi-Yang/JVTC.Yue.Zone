package com.neu.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.neu.pojo.User;
/**
 * user表持久层接口
 * @author Admin
 *
 */
@Mapper
public interface UserMapper {
	
	//代码编写处

	
	
}
