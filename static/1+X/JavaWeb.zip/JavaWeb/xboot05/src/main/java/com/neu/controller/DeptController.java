package com.neu.controller;



import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/depts")
public class DeptController  {
	
	//代码编写处
	
	
	
	
	

}
