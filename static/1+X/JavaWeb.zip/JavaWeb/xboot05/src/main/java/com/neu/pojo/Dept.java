package com.neu.pojo;

/**
 * 对应dept表的JavaBean
 * @author Admin
 *
 */
public class Dept {

	public String getDeptno() {
		return deptno;
	}
	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	
	private String deptno;
	private String dname;
	private String loc;
	
	
	
	
}
