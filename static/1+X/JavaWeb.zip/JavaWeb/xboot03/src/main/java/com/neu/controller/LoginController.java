package com.neu.controller;


public class LoginController {
	
	//代码编写处


}
