package com.neu.mapper;

import org.apache.ibatis.annotations.Mapper;


/**
 * user表持久层接口
 * @author Admin
 *
 */
@Mapper
public interface UserMapper {
	
	//代码编写处

	
	
}
