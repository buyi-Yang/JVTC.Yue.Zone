create table if not exists user
(
    id           int auto_increment
        primary key,
    name         tinytext not null,
    password     tinytext not null,
    departmentId tinyint  not null
)
    collate = utf8mb4_zh_0900_as_cs;

INSERT INTO test.user (id, name, password, departmentId) VALUES (1, 'AAA', 'AAA', 1);
INSERT INTO test.user (id, name, password, departmentId) VALUES (2, 'BBB', 'BBB', 2);
INSERT INTO test.user (id, name, password, departmentId) VALUES (3, 'CCC', 'CCC', 3);

