package zone.yue.jvtc.exp16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp16Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp16Application.class, args);
	}

}
