package zone.yue.jvtc.exp16;

interface UserService {
    User getById(Long id);
}
