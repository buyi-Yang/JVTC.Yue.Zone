package zone.yue.jvtc.exp16;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.SpringVersion;
import org.springframework.web.servlet.DispatcherServlet;

@SpringBootTest
class Exp16ApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void printVersions() {
		System.out.println("Spring 版本: " + SpringVersion.getVersion());
		System.out.println("Spring MVC 版本: " + DispatcherServlet.class.getPackage().getImplementationVersion());
		System.out.println("MyBatis 版本: " + SqlSessionFactory.class.getPackage().getImplementationVersion());
	}
}
