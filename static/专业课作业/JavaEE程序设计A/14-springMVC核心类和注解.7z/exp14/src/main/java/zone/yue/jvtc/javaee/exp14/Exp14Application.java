package zone.yue.jvtc.javaee.exp14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp14Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp14Application.class, args);
	}

}
