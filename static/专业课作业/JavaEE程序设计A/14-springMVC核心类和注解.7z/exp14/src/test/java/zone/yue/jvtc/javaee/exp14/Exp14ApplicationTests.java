package zone.yue.jvtc.javaee.exp14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
