package zone.yue.jvtc.javaee;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DeptMapper {
    @Select("SELECT * FROM dept;")
    List<DeptPojo> findAll();

    DeptPojo findById(Long id);

    List<DeptPojo> findByNameAndPid(@Param("name") String name, @Param("pid") Long pid);

    List<DeptPojo> findByNameLike(String name);

    List<DeptPojo> findByIdList(@Param("list") List<Long> idList);

    Boolean insert(DeptPojo pojo);

    Integer update(DeptPojo pojo);

    Integer updateDept(
            @Param("id") Long id,
            @Param("name") String name,
            @Param("pid") Long pid,
            @Param("tips") String tips
    );

    Boolean deleteById(Long id);
}
