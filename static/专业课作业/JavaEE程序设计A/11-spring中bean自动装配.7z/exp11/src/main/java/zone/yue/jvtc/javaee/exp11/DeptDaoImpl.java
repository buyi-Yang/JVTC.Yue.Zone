package zone.yue.jvtc.javaee.exp11;

import org.springframework.stereotype.Repository;

@Repository
public class DeptDaoImpl implements DeptDao {
    @Override
    public void updateById() {
        System.out.println("Hello World!");
    }
}
