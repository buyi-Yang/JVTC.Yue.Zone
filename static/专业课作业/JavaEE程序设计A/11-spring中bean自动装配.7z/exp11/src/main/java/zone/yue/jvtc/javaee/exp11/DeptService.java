package zone.yue.jvtc.javaee.exp11;

import org.springframework.stereotype.Service;

@Service
public class DeptService {
    DeptDaoImpl deptDao;

    DeptService(DeptDaoImpl deptDao) {
        this.deptDao = deptDao;
    }

    public void update() {
        deptDao.updateById();
    }
}
