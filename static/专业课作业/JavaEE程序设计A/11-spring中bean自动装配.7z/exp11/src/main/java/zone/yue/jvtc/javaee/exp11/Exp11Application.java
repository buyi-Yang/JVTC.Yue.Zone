package zone.yue.jvtc.javaee.exp11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp11Application {

    public static void main(String[] args) {
        SpringApplication.run(Exp11Application.class, args);
    }

}
