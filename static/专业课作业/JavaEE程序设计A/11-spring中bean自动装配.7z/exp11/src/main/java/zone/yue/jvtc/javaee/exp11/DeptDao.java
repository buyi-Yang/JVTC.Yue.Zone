package zone.yue.jvtc.javaee.exp11;

public interface DeptDao {
    void updateById();
}
