package zone.yue.jvtc.javaee.exp11;

import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

@SpringBootTest
class Exp11ApplicationTests {
    @Autowired
    private ApplicationContext applicationContext;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Test
    void contextLoads() {
    }

    @Test
    void getBean() {
        var deptServiceBean = (DeptService) applicationContext.getBean("deptService");
        logger.info("========================================================="::toString);
        logger.warn(deptServiceBean::toString);
        deptServiceBean.update();
        logger.info("========================================================="::toString);
    }
}
