package zone.yue.jvtc.javaee.exp13;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

@Controller
public class CardController {
    @RequestMapping("/moreInformation")
    public String moreInformation() {
        return "moreInformation";
    }

    @ResponseBody
    @RequestMapping("/modifyPageRedirects")
    public void modifyPageRedirects(HttpServletResponse response) throws IOException {
        response.sendRedirect("/moreInformation");
    }

    @RequestMapping("/updateInformation")
    public String updateInformation() {
        return "updateInformation";
    }
}
