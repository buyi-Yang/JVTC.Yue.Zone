package zone.yue.jvtc.javaee.exp13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp13Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp13Application.class, args);
	}

}
