package zone.yue.jvtc.javaee;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

import java.io.IOException;

public class DeptTest {
    Logger logger = LoggerFactory.getLogger(this.getClass());
    DeptMapper mapper;

    DeptTest() throws IOException {
        this.mapper = new SqlSessionFactoryBuilder()
                .build(Resources.getResourceAsStream("mybatis-config.xml"))
                .openSession()
                .getMapper(DeptMapper.class);
    }

    @Test
    void testFindAll() {
        logger.info(mapper.findAll()::toString);
    }

    @Test
    void testFindById() {
        logger.info(mapper.findById(1L)::toString);
    }

    @Test
    void testFindByNameLike() {
        logger.info(mapper.findByNameLike("端")::toString);
    }
}
