package zone.yue.jvtc.javaee.exp12;

import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;

public class DeptDaoImplTest {
    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Test
    public void test() {
        DeptDaoImpl deptDao = new DeptDaoImpl();
        Class<DeptDaoImplAspect> deptDaoImplAspectClass = DeptDaoImplAspect.class;
        AspectJProxyFactory aspectJProxyFactory = new AspectJProxyFactory();

        aspectJProxyFactory.setTarget(deptDao);
        aspectJProxyFactory.addAspect(deptDaoImplAspectClass);

        DeptDaoImpl proxy = aspectJProxyFactory.getProxy();

        proxy.update();
        logger.info("========================================="::toString);
        proxy.throwingUpdate();
    }
}
