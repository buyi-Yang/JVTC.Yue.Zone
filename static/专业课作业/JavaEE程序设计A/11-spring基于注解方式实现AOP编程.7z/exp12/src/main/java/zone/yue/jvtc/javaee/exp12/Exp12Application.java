package zone.yue.jvtc.javaee.exp12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp12Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp12Application.class, args);
	}

}
