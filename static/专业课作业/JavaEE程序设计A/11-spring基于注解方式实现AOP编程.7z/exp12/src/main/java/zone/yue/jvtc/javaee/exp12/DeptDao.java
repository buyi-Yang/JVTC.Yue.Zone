package zone.yue.jvtc.javaee.exp12;

public interface DeptDao {
    void update();
}
