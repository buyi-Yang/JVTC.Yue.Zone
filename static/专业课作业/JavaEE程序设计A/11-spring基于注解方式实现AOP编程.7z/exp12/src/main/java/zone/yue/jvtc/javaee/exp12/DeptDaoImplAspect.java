package zone.yue.jvtc.javaee.exp12;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * （3）	编写切面：切入点对DeptDaoImpl类中的update添加前置、后置、返回、异常、环绕通知，并采用@Pointcut注解抽取各类通知中相同的切入点表达式。
 */
@Aspect
@Configuration
@EnableAspectJAutoProxy
public class DeptDaoImplAspect {
    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Pointcut("execution(* zone.yue.jvtc.javaee.exp12.DeptDaoImpl.update())")
    public void updateExecution() {}

    @Pointcut("execution(* zone.yue.jvtc.javaee.exp12.DeptDaoImpl.throwingUpdate())")
    public void throwingUpdateExecution() {}

    @Before("updateExecution()")
    public void updateBefore() {
        logger.info("===========updateBefore");
    }

    @After("updateExecution()")
    public void updateAfter() {
        logger.info("===========updateAfter");
    }

    @AfterReturning("updateExecution()")
    public void updateAfterReturning() {
        logger.info("===========updateAfterReturning");
    }

    @AfterThrowing("updateExecution()")
    public void updateAfterThrowing() {
        logger.info("===========updateAfterThrowing");
    }

    @Around("throwingUpdateExecution()")
    public Object updateAround(ProceedingJoinPoint pjp) throws Throwable {
        logger.info("===========updateAround");
        return pjp.proceed();
    }
}
