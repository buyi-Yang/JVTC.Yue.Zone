package zone.yue.jvtc.javaee.exp12;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class DeptDaoImpl implements DeptDao {
    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void update() {
        logger.info("Hello World!");
    }

    public void throwingUpdate() {
        logger.warn("Hello World!");
        throw new RuntimeException("主动抛出异常！");
    }
}
