package zone.yue.jvtc.javaee;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

import java.io.IOException;

public class DeptTest {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DeptTest.class);
    Logger logger = LoggerFactory.getLogger(this.getClass());
    DeptMapper mapper;

    @SuppressWarnings("resource")
    DeptTest() throws IOException {
        this.mapper = new SqlSessionFactoryBuilder()
                .build(Resources.getResourceAsStream("mybatis-config.xml"))
                .openSession(true)
                .getMapper(DeptMapper.class);
    }

    @Test
    void testFindAll() {
        logger.info(mapper.findAll()::toString);
    }

    @Test
    void testFindById() {
        logger.info(mapper.findById(1L)::toString);
    }

    @Test
    void testFindByNameLike() {
        logger.info(mapper.findByNameLike("端")::toString);
    }

    @Test
    void testInsert() {
        DeptPojo deptPojo = new DeptPojo(null, "AAA", 4L, "tips");
        logger.info(mapper.insert(deptPojo)::toString);
        logger.info(deptPojo::toString);
    }

    @Test
    void testUpdate() {
        logger.info(mapper.update(new DeptPojo(1L, "AAA", 4L, "tips"))::toString);
    }

    @Test
    void testDeleteById() {
        logger.info(mapper.deleteById(3L)::toString);
    }
}
