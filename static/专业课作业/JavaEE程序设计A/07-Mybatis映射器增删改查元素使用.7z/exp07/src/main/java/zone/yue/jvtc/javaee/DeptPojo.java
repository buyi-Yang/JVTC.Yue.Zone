package zone.yue.jvtc.javaee;

import java.beans.JavaBean;

@JavaBean
public class DeptPojo {
    Long id;
    String name;
    Long pid;
    String tips;

    public DeptPojo(Long id, String name, Long pid, String tips) {
        this.id = id;
        this.name = name;
        this.pid = pid;
        this.tips = tips;
    }

    public DeptPojo() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

    @Override
    public String toString() {
        return "DeptPojo{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pid=" + pid +
                ", tips='" + tips + '\'' +
                '}';
    }
}
