package zone.yue.jvtc.javaee.exp15;

public class CardPojo {
    private Long id;
    private Long userId;
    private String cardNo;
    private Integer balance;

    public CardPojo() {
        this.id = -1L;
        this.userId = -1L;
        this.cardNo = "0000000000000000";
        this.balance = 0;
    }

    public CardPojo(Long id, Long userId, String cardNo, Integer balance) {
        this.id = id;
        this.userId = userId;
        this.cardNo = cardNo;
        this.balance = balance;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "CardPojo{" +
                "id=" + id +
                ", userId=" + userId +
                ", cardNo='" + cardNo + '\'' +
                ", balance=" + balance +
                '}';
    }
}
