package zone.yue.jvtc.javaee.exp15;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CardController {
    @RequestMapping("/{id}")
    String id(Model model, @PathVariable Long id) {
        model.addAttribute("id", id);
        model.addAttribute("card", new CardPojo());
        return "details";
    }

    @PostMapping("/post")
    String post(Model model, @RequestBody CardPojo card) {
        model.addAttribute("id", card.getId());
        model.addAttribute("card", card);
        return "details";
    }
}
