package zone.yue.jvtc.javaee.exp15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp15Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp15Application.class, args);
	}

}
