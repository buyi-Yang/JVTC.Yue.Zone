package zone.yue.jvtc.javaee.exp15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
