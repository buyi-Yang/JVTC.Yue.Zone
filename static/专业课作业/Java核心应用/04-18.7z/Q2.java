import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * 对窗体上容器contentPane进行鼠标移动监听，显示鼠标所在位置的x轴和y轴的值
 */
public class Q2 extends JFrame {
    private final JLabel label;

    public Q2() {
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label = new JLabel();
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.CENTER);

        Container contentPane = getContentPane();
        contentPane.add(label, BorderLayout.CENTER);

        contentPane.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                label.setText("鼠标位置: (" + e.getX() + ", " + e.getY() + ")");
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Q2();
    }
}
