import javax.swing.*;
import java.awt.event.*;

/**
 * 对窗体进行监听，当用户点击关闭按钮时用弹出对话框的方式提示“是否关闭”，如果用户点击确认则将窗体关闭
 */
public class Q1 extends JFrame {
    public Q1() {
        this.setSize(300, 200);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int option = JOptionPane.showConfirmDialog(
                        Q1.this,
                        "是否关闭？",
                        "确认",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );
                if (option == JOptionPane.YES_OPTION) {
                    if (e.getWindow() == Q1.this) {
                        System.exit(0);
                    }
                }
            }
        });
    }

    public static void main(String[] args) {
        new Q1().setVisible(true);
    }
}
