import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * 通过随机方式产生两数的运算（+、-、X、/），当用户通过输入框输入正确答案并按下Enter键时判断用户是否回答正确
 */
public class Q4 extends JFrame {
    private final JTextField answerField;
    private final JLabel mathProblemLabel;
    private double correctAnswer;

    public Q4() {
        setSize(500, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mathProblemLabel = new JLabel();
        mathProblemLabel.setHorizontalAlignment(JLabel.CENTER);
        mathProblemLabel.setVerticalAlignment(JLabel.CENTER);
        mathProblemLabel.setFont(new Font("Serif", Font.PLAIN, 64));

        answerField = new JTextField();
        answerField.addActionListener(_ -> {
            try {
                double userAnswer = Double.parseDouble(answerField.getText());
                if (userAnswer == correctAnswer) JOptionPane.showMessageDialog(null, "回答正确！");
                else JOptionPane.showMessageDialog(null, "回答错误！正确答案为：" + correctAnswer);
                generateMathProblem();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(
                        null,
                        e.getLocalizedMessage(),
                        e.getClass().getName(),
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        Container contentPane = getContentPane();
        contentPane.add(mathProblemLabel, BorderLayout.CENTER);
        contentPane.add(answerField, BorderLayout.SOUTH);

        generateMathProblem();

        setVisible(true);
    }

    private void generateMathProblem() {
        Random rand = new Random();
        int num1 = rand.nextInt(10);
        int num2 = rand.nextInt(10);
        char operator = "+-*/".charAt(rand.nextInt(4));

        switch (operator) {
            case '+' -> correctAnswer = num1 + num2;
            case '-' -> correctAnswer = num1 - num2;
            case '*' -> correctAnswer = num1 * num2;
            case '/' -> {
                if (num2 != 0) correctAnswer = (double) num1 / num2;
                else generateMathProblem();
            }
            default -> generateMathProblem();
        }

        mathProblemLabel.setText(num1 + " " + operator + " " + num2 + " = ?");
        answerField.setText("");
    }

    public static void main(String[] args) {
        new Q4();
    }
}
