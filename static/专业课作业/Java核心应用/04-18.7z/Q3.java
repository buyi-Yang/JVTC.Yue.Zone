import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

/**
 * 将窗体上的容器布置成中部和南部两个部位的边界式布局，在中部放置一张动态抽奖图片，在南部放置一个提问按钮，当点击按钮时随机抽取学生进行问题解答。
 */
public class Q3 extends JFrame {
    private final String[] students = {"学生1", "学生2", "学生3", "学生4", "学生5"};

    public Q3() {
        this.setSize(600, 600);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setLayout(new BorderLayout());

        JLabel lotteryImage = new JLabel(new ImageIcon("img.gif"));
        this.add(lotteryImage, BorderLayout.CENTER);

        JButton questionButton = new JButton("提问");
        questionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String student = students[new Random().nextInt(students.length)];
                JOptionPane.showMessageDialog(Q3.this, student + "请回答问题");
            }
        });
        this.add(questionButton, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        new Q3().setVisible(true);
    }
}
