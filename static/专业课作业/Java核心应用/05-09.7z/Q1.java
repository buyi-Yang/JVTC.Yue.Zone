import java.util.Scanner;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入预订日期（格式：YYYY-MM-DD）:");
        String dateInput = scanner.nextLine();
        LocalDate bookingDate = LocalDate.parse(dateInput);
        LocalDate currentDate = LocalDate.now();

        long daysBetween = ChronoUnit.DAYS.between(currentDate, bookingDate);
        if (daysBetween < 0) {
            System.out.println("不能购买过去的票。");
            return;
        }
        if (daysBetween > 90) {
            System.out.println("只可提前90天预订。");
            return;
        }

        System.out.println("请输入舱位类型（头等舱/经济舱）:");
        String cabinType = scanner.nextLine();

        double discount;
        int month = bookingDate.getMonthValue();
        if (month == 3 || month == 4 || month == 5 || month == 6 || month == 11 || month == 12) {
            // 淡季
            discount = cabinType.equals("头等舱") ? 0.85 : 0.8;
        } else {
            // 旺季
            discount = cabinType.equals("头等舱") ? 0.95 : 0.9;
        }

        double price = 2000 * discount;
        System.out.println("您的票价为：" + price + "元");
    }
}
