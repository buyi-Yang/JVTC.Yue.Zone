interface Q4Student {
    void setTuition(double tuition);
    double getTuition();
}

interface Q4Teacher {
    void setSalary(double salary);
    double getSalary();
}

class Graduate implements Q4Student, Q4Teacher {
    private double tuition;
    private double salary;

    public void setTuition(double tuition) {
        this.tuition = tuition;
    }

    public double getTuition() {
        return this.tuition;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getSalary() {
        return this.salary;
    }
}

public class Q4 {
    public static void main(String[] args) {
        Graduate graduate = new Graduate();

        graduate.setTuition(5000.0);
        System.out.println("学费是: " + graduate.getTuition());

        graduate.setSalary(8000.0);
        System.out.println("工资是: " + graduate.getSalary());
    }
}
