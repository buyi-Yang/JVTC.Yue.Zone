abstract class Shape {
    abstract double getArea();
    abstract double getPerimeter();
}

class Circle extends Shape {
    private final double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * Math.pow(radius, 2);
    }

    @Override
    double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}

class Square extends Shape {
    private final double side;

    public Square(double side) {
        this.side = side;
    }

    @Override
    double getArea() {
        return Math.pow(side, 2);
    }

    @Override
    double getPerimeter() {
        return 4 * side;
    }
}

class Q2 {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println("圆形面积：" + circle.getArea());
        System.out.println("圆形周长：" + circle.getPerimeter());

        Square square = new Square(4);
        System.out.println("方形面积：" + square.getArea());
        System.out.println("方形周长：" + square.getPerimeter());
    }
}
