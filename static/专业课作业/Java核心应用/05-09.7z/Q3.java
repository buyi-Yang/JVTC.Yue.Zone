abstract class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    abstract void speak();
}

class Worker extends Person {
    double salary;

    Worker(String name, int age, double salary) {
        super(name, age);
        this.salary = salary;
    }

    @Override
    void speak() {
        System.out.println("我是一个工人，我的名字是 " + name + "，我 " + age + " 岁，我赚 " + salary + " 元。");
    }
}

class Student extends Person {
    double score;

    Student(String name, int age, double score) {
        super(name, age);
        this.score = score;
    }

    @Override
    void speak() {
        System.out.println("我是一个学生，我的名字是 " + name + "，我 " + age + " 岁，我的成绩是 " + score + " 分。");
    }
}

public class Q3 {
    public static void main(String[] args) {
        Worker worker = new Worker("张三", 35, 5000);
        Student student = new Student("李四", 20, 90);

        worker.speak();
        student.speak();
    }
}
