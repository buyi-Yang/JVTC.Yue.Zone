import javax.swing.*;

public class Q4 extends JFrame implements Runnable {
    private final JLabel imageLabel;
    private int xPos = 0;

    public Q4() {
        setSize(1000, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        ImageIcon imageIcon = new ImageIcon("mer.gif");
        imageLabel = new JLabel(imageIcon);
        add(imageLabel);

        Thread thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        while (true) {
            if (xPos + imageLabel.getWidth() >= getWidth()) {
                xPos = 0;
            } else {
                xPos += 1;
            }

            imageLabel.setBounds(xPos, 0, imageLabel.getIcon().getIconWidth(), imageLabel.getIcon().getIconHeight());

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            repaint();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q4().setVisible(true);
            }
        });
    }
}
