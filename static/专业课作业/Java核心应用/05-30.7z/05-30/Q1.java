import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.stream.IntStream;

public class Q1 {
    public static void main(String[] args) {
        Path inputFile = Paths.get("input.txt");
        Path outputFile = Paths.get("output.txt");

        try {
            byte[] inputBytes = Files.readAllBytes(inputFile);
            int length = inputBytes.length;

            IntStream.range(0, length).map(i -> inputBytes[length - 1 - i]).forEach(b -> {
                try {
                    Files.write(outputFile, new byte[]{(byte) b}, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });

            System.out.println("文件保存到：" + outputFile);
        } catch (IOException e) {
            System.out.println("发生错误: " + e.getMessage());
        }
    }
}
