public class Q2 {
    public static void main(String[] args) throws InterruptedException {
        final var text = new String[]{"第一行文本", "第二行文本", "第三行文本"};

        for (String line : text) {
            var ms = 200;
            for (char t : line.toCharArray()) {
                System.out.print(t);
                Thread.sleep(ms);
                ms += 200;
            }
            System.out.println();
        }
    }
}
