import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Q1 extends JFrame {
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int BALLOON_COUNT = 5;
    private static final int BALLOON_SPACING = 50;
    private static final int MAX_DELAY = 5000;

    private final List<Point> balloons;
    private final List<Color> balloonColors;
    private final List<Integer> balloonDelays;

    public Q1() {
        setTitle("逐渐上升的气球");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        balloons = new ArrayList<>();
        balloonColors = new ArrayList<>();
        balloonDelays = new ArrayList<>();
        generateBalloons();

        BalloonPanel balloonPanel = new BalloonPanel();
        balloonPanel.setBackground(Color.CYAN);
        add(balloonPanel);

        setVisible(true);

        startAnimation();
    }

    private void generateBalloons() {
        int totalWidth = BALLOON_COUNT * (BalloonPanel.BALLOON_WIDTH + BALLOON_SPACING) - BALLOON_SPACING;
        int startX = (FRAME_WIDTH - totalWidth) / 2;

        Random random = new Random();

        for (int i = 0; i < BALLOON_COUNT; i++) {
            int x = startX + i * (BalloonPanel.BALLOON_WIDTH + BALLOON_SPACING);
            balloons.add(new Point(x, FRAME_HEIGHT));

            int red = random.nextInt(256);
            int green = random.nextInt(256);
            int blue = random.nextInt(256);
            Color color = new Color(red, green, blue);
            balloonColors.add(color);

            int delay = random.nextInt(MAX_DELAY);
            balloonDelays.add(delay);
        }
    }

    private void startAnimation() {
        for (int i = 0; i < BALLOON_COUNT; i++) {
            int index = i;
            Timer timer = new Timer(balloonDelays.get(i), e -> {
                Point balloon = balloons.get(index);
                balloon.y -= 1;
                repaint();

                if (balloon.y > 0) {
                    Timer nextTimer = new Timer(20, evt -> {
                        Point nextBalloon = balloons.get(index);
                        nextBalloon.y -= 1;
                        repaint();
                    });
                    nextTimer.setRepeats(true);
                    nextTimer.start();
                }
            });
            timer.setRepeats(false);
            timer.start();
        }
    }

    private class BalloonPanel extends JPanel {
        private static final int BALLOON_WIDTH = 100;
        private static final int BALLOON_HEIGHT = 150;

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            for (int i = 0; i < balloons.size(); i++) {
                Point balloon = balloons.get(i);
                int x = balloon.x;
                int y = balloon.y;
                Color color = balloonColors.get(i);

                g.setColor(color);
                g.fillOval(x, y, BALLOON_WIDTH, BALLOON_HEIGHT);

                g.setColor(Color.black);
                int textX = x + (BALLOON_WIDTH) / 2;
                int textY = y + BALLOON_HEIGHT / 2;
                g.drawString("", textX, textY);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Q1::new);
    }
}
