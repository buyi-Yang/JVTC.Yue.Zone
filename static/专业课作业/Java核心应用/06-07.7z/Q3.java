import java.util.Random;

public class Q3 {
    public static class Channel implements Runnable {
        private final TicketSeller ticketSeller;
        private final Random rand = new Random();

        public Channel(TicketSeller ticketSeller) {
            this.ticketSeller = ticketSeller;
        }

        @Override
        @SuppressWarnings({"BusyWait"})
        public void run() {
            while (true) {
                ticketSeller.sellTicket();
                if (ticketSeller.tickets == 0) {
                    break;
                }

                try {
                    Thread.sleep(rand.nextLong(1000));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static class TicketSeller {
        private int tickets = 10;

        public synchronized void sellTicket() {
            if (tickets > 0) {
                System.out.println(Thread.currentThread().getName() + "卖出了1张票，剩余" + --tickets + "张票");
            }
        }
    }

    public static void main(String[] args) {
        TicketSeller ticketSeller = new TicketSeller();
        Channel channel1 = new Channel(ticketSeller);
        Channel channel2 = new Channel(ticketSeller);
        Channel channel3 = new Channel(ticketSeller);

        new Thread(channel1, "12306").start();
        new Thread(channel2, "飞猪").start();
        new Thread(channel3, "携程").start();
    }
}
