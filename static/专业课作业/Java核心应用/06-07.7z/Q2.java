public class Q2 {
    static class Rabbit implements Runnable {
        @Override
        public void run() {
            try {
                System.out.println("兔子线程状态：" + Thread.currentThread().getState());
                System.out.println("兔子正在睡大觉");
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                System.out.println("兔子被叫醒");
                System.out.println("兔子开始跑步......................");
            }
        }
    }

    static class Turtle implements Runnable {
        private final Thread rabbit;

        public Turtle(Thread rabbit) {
            this.rabbit = rabbit;
        }

        @Override
        @SuppressWarnings("CallToPrintStackTrace")
        public void run() {
            System.out.println("乌龟线程状态：" + Thread.currentThread().getState());
            try {
                Thread.sleep(3000);
                System.out.println("乌龟大叫：跑步去！");
                System.out.println("当前活动的线程数：" + Thread.activeCount());
                rabbit.interrupt();
                System.out.println("乌龟开始跑步");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("程序刚开始运行的线程名：" + Thread.currentThread().getName());
        System.out.println(Thread.currentThread().getName() + "线程状态" + Thread.currentThread().getState());
        System.out.println("当前活动的线程数：" + Thread.activeCount());

        Thread rabbit = new Thread(new Rabbit());
        Thread turtle = new Thread(new Turtle(rabbit));

        System.out.println("兔子线程状态" + rabbit.getState());
        System.out.println("乌龟线程状态" + turtle.getState());

        rabbit.start();
        turtle.start();

        rabbit.join();
        turtle.join();
    }
}
