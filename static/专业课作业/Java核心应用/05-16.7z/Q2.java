import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Q2 {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setBounds(300, 200, 400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());

        JLabel label = new JLabel("请输入要查找的单词：");
        JTextField textField = new JTextField(20);
        JButton button = new JButton("查询");
        JTextArea resultArea = new JTextArea(3, 10);
        resultArea.setEditable(false);

        Map<String, String> dictionary = new HashMap<>();
        dictionary.put("apple", "苹果");
        dictionary.put("banana", "香蕉");
        dictionary.put("orange", "橙子");

        button.addActionListener(_ -> {
            String input = textField.getText();
            String output = dictionary.get(input);
            resultArea.setText(Objects.requireNonNullElse(output, "未找到对应的英文单词。"));
        });

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(label, constraints);

        constraints.gridy = 1;
        panel.add(textField, constraints);

        constraints.gridy = 2;
        constraints.fill = GridBagConstraints.BOTH;
        panel.add(new JScrollPane(resultArea), constraints);

        constraints.gridy = 3;
        panel.add(button, constraints);

        frame.add(panel);
        frame.setVisible(true);
    }
}
