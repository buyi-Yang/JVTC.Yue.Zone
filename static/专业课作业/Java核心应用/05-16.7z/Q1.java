import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Map<String, String> students = new HashMap<>();
        students.put("001", "张三");
        students.put("002", "李四");
        students.put("003", "王五");

        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入学生学号：");

        String id = scanner.nextLine();
        String name = students.get(id);

        if (name != null) System.out.println("学号" + id + "；姓名：" + name);
        else System.out.println("未找到学号为" + id + "的学生");

        scanner.close();
    }
}
