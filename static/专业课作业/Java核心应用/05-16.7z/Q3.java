import java.util.*;
import java.util.Scanner;

public class Q3 {
    private final Map<Integer, String> students;
    private final Random random;

    public Q3() {
        this.students = new HashMap<>();
        this.random = new Random();
    }

    public void addStudent(int id, String name) {
        students.put(id, name);
    }

    public String call() {
        if (students.isEmpty()) return "没有学生在班级里";

        int index = random.nextInt(students.size());
        int id = (int) students.keySet().toArray()[index];
        return students.get(id);
    }

    public static void main(String[] args) {
        Q3 randomCall = new Q3();
        Scanner scanner = new Scanner(System.in);

        System.out.println("请输入学生数量：");
        int N = scanner.nextInt();

        for (int i = 1; i <= N; i++) {
            randomCall.addStudent(i, "学生" + i);
        }

        System.out.println("请输入要点名的学生数量：");
        int callNum = scanner.nextInt();

        for (int i = 0; i < callNum; i++) {
            System.out.print(randomCall.call() + ", ");
        }

        scanner.close();
    }
}
