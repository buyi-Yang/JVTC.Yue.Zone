import java.util.*;
import java.util.Scanner;

public class Q4 {
    private final Map<Integer, String> maleStudents;
    private final Map<Integer, String> femaleStudents;
    private final Random random;

    public Q4() {
        this.maleStudents = new HashMap<>();
        this.femaleStudents = new HashMap<>();
        this.random = new Random();
    }

    public void addStudent(int id, String name) {
        String gender = random.nextInt(10) < 5 ? "男" : "女";
        if (gender.equals("男")) maleStudents.put(id, name + "（男）");
        else femaleStudents.put(id, name + "（女）");
    }

    public String call() {
        if (maleStudents.isEmpty() && femaleStudents.isEmpty()) return "没有学生在班级里";

        Map<Integer, String> targetStudents = random.nextInt(10) < 7 ? maleStudents : femaleStudents;

        if (targetStudents.isEmpty()) targetStudents = targetStudents == maleStudents ? femaleStudents : maleStudents;

        int index = random.nextInt(targetStudents.size());
        int id = (int) targetStudents.keySet().toArray()[index];
        return targetStudents.get(id);
    }

    public void printlnMaleStudents() {
        System.out.println("=======================================");
        System.out.println("生成了" + maleStudents.size() + "名女同学：" + maleStudents);
        System.out.println("=======================================");
    }

    public void printlnFemaleStudents() {
        System.out.println("=======================================");
        System.out.println("生成了" + femaleStudents.size() + "名女同学：" + femaleStudents);
        System.out.println("=======================================");
    }

    @SuppressWarnings("DuplicatedCode")
    public static void main(String[] args) {
        var q4 = new Q4();
        var scanner = new Scanner(System.in);

        System.out.println("请输入学生数量：");
        int N = scanner.nextInt();

        for (int i = 1; i <= N; i++) q4.addStudent(i, "学生" + i);

        q4.printlnMaleStudents();
        q4.printlnFemaleStudents();

        System.out.println("请输入要点名的学生数量：");
        int callNum = scanner.nextInt();

        for (int i = 0; i < callNum; i++) System.out.println(q4.call());

        scanner.close();
    }
}
