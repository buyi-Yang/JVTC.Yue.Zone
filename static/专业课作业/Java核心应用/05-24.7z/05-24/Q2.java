import java.io.File;
import java.io.IOException;

public class Q2 {
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        File file = new File("C:\\Users\\YuePlus\\test\\文件.txt");
        if (file.exists()) {
            if (file.delete()) System.out.println("文件已存在并已被删除：" + file.getName());
            else System.out.println("文件存在，但无法删除。");
        } else {
            try {
                if (file.createNewFile()) System.out.println("文件不存在，已创建新文件：" + file.getName());
                else System.out.println("文件不存在，但无法创建新文件。");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
