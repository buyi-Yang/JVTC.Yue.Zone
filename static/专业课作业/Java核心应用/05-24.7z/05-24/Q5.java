import java.io.FileOutputStream;
import java.io.IOException;

public class Q5 {
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        try (FileOutputStream fos = new FileOutputStream("C:\\Users\\YuePlus\\test\\成绩表.txt")) {
            fos.write("张三 男 20岁 JAVA成绩：90分".getBytes());
            System.out.println("数据已成功写入");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
