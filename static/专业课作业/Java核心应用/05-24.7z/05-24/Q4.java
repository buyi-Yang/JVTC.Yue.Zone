import java.io.File;
import java.util.Objects;

public class Q4 {
    public static void main(String[] args) {
        for(String file : Objects.requireNonNull(new File("C:\\").list())) {
            System.out.println(file);
        }
    }
}
