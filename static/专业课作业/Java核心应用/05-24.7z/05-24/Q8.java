import javax.swing.*;
import java.awt.*;
import java.io.FileOutputStream;
import java.io.IOException;

public class Q8 {
    static class Window {
        public Window() {
            final JFrame frame;
            final JTextField usernameField;
            final JPasswordField passwordField;
            final JButton loginButton;

            frame = new JFrame("简单键盘记录器");
            frame.setSize(300, 150);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));


            JPanel usernamePanel = new JPanel();
            JLabel usernameLabel = new JLabel("姓名：");
            usernameField = new JTextField(15);
            usernamePanel.add(usernameLabel);
            usernamePanel.add(usernameField);

            JPanel passwordPanel = new JPanel();
            JLabel passwordLabel = new JLabel("密码：");
            passwordField = new JPasswordField(15);
            passwordPanel.add(passwordLabel);
            passwordPanel.add(passwordField);

            loginButton = new JButton("登录");
            loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            loginButton.addActionListener(_ -> {
                var username = usernameField.getText();
                var password = new String(passwordField.getPassword());

                if (username.isEmpty() || password.isEmpty())
                    JOptionPane.showMessageDialog(null, "用户名或密码为空！");

                try (FileOutputStream fos = new FileOutputStream("C:\\Users\\YuePlus\\test\\Log.txt")) {
                    fos.write(("姓名：" + username + "，密码：" + password).getBytes());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });

            panel.add(usernamePanel);
            panel.add(passwordPanel);
            panel.add(loginButton);

            frame.getContentPane().add(panel, BorderLayout.CENTER);
            frame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Window();
    }
}
