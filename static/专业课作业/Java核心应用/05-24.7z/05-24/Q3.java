import java.io.File;
import java.io.IOException;

public class Q3 {
    public static void main(String[] args) {
        var dir = new File("C:\\Users\\YuePlus\\test\\文件夹");

        if (dir.mkdir()) System.out.println("创建文件夹成功");
        else System.out.println("创建文件夹失败");

        if(dir.exists()) System.out.println("文件夹已存在");
    }
}
