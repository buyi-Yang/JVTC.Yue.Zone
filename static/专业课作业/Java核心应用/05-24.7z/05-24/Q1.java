import java.io.File;
import java.io.IOException;

public class Q1 {
    @SuppressWarnings({"CallToPrintStackTrace", "ResultOfMethodCallIgnored"})
    public static void main(String[] args) {
        try {
            new File("C:\\Users\\YuePlus\\test\\文件.txt").createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
