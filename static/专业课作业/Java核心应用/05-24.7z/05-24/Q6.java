import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Q6 {
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        try (FileOutputStream fos = new FileOutputStream("C:\\Users\\YuePlus\\test\\成绩表.txt", true)) {
            fos.write("\n李四 男 19岁 JAVA成绩：87分".getBytes());
            System.out.println("数据已成功追加");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
