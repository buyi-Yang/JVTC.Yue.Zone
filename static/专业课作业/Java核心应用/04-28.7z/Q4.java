import java.util.Scanner;

class Calculator {
   public static void fourArithmetic(String num1, String operator, String num2) {
       try {
           record Formula(double n1, char operator, double n2) {
               void printCalculationResult(double result) {
                   System.out.println(n1 + " " + operator + " " + n2 + " = " + result);
               }
           }

           var formula = new Formula(
                   Double.parseDouble(num1.trim()),
                   operator.toCharArray()[0],
                   Double.parseDouble(num2.trim())
           );

           switch (formula.operator) {
               case '+' -> formula.printCalculationResult(formula.n1 + formula.n2);
               case '-' -> formula.printCalculationResult(formula.n1 - formula.n2);
               case '*' -> formula.printCalculationResult(formula.n1 * formula.n2);
               case '/' -> {
                   if (formula.n2 == 0) {
                       System.out.println("被除数不能为 0 ！");
                       break;
                   }
                   formula.printCalculationResult(formula.n1 / formula.n2);
               }
               default -> System.out.println("运算符只能输入 + - * / 你输入的运算符不正确！");
           }
       } catch (NumberFormatException e) {
           System.out.println("输入的类型不正确！");
       }

       System.out.println("感谢您的使用！");
   }
}

public class Q4 {
    @SuppressWarnings({"CallToPrintStackTrace", "RedundantSuppression"})
    public static void main(String[] args) {
        try (var sc = new Scanner(System.in)) {
            do {
                System.out.println("请输入计算式：");
                Calculator.fourArithmetic(sc.next(), sc.next(), sc.next());
            } while (sc.hasNext());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
