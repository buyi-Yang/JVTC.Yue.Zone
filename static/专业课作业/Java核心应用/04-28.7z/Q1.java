class DevideZeroException extends Exception {
    public DevideZeroException(String message) {
        super(message);
    }
}

public class Q1 {
    public static int divide(int numerator, int denominator) throws DevideZeroException {
        if (denominator == 0) throw new DevideZeroException("分母不能为0");
        return numerator / denominator;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        try {
            int result = Q1.divide(10, 0);
            System.out.println("结果是: " + result);
        } catch (DevideZeroException e) {
            e.printStackTrace();
        }
    }
}
