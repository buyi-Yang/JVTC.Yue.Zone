class LoginException extends Exception {
    public LoginException(String message) {
        super(message);
    }
}

record User(String username, String password) {}

class LoginSystem {
    private final User user;

    public LoginSystem(User user) {
        this.user = user;
    }

    public void login(String username, String password) throws LoginException {
        if (!this.user.username().equals(username)) throw new LoginException("用户名不存在");
        if (!this.user.password().equals(password)) throw new LoginException("密码不正确");
        System.out.println("登录成功");
    }
}

public class Q3 {
    @SuppressWarnings({"CallToPrintStackTrace", "RedundantSuppression"})
    public static void main(String[] args) {
        User user = new User("admin", "123456");
        LoginSystem system = new LoginSystem(user);

        try {
            system.login("admin", "123456"); // 正确的用户名和密码
            system.login("admin", "wrong_password"); // 错误的密码
        } catch (LoginException e) {
            e.printStackTrace();
        }

        try {
            system.login("wrong_username", "123456"); // 错误的用户名
        } catch (LoginException e) {
            e.printStackTrace();
        }
    }
}
