class InvalidScoreException extends Exception {
    public InvalidScoreException(String message) {
        super(message);
    }
}

class Student {
    private final String name;
    private int score;

    public Student(String name, int score) throws InvalidScoreException {
        this.name = name;
        setScore(score);
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) throws InvalidScoreException {
        if (score < 0 || score > 100) {
            throw new InvalidScoreException("分数必须在0到100之间");
        }
        this.score = score;
    }
}

public class Q2 {
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        try {
            Student student = new Student("张三", 110);
        } catch (InvalidScoreException e) {
            e.printStackTrace();
        }
    }
}
