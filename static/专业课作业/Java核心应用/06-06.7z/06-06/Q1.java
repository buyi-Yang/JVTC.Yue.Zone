import javax.swing.*;
import java.awt.*;

public class Q1 extends JFrame implements Runnable {
    private final String[] ad = {"九江介绍：好吃就在九龙街", "九江介绍：好玩就在庐山"};
    private final JLabel label;
    private int index = 0;

    Q1(String title) {
        label = new JLabel();
        label.setFont(new Font("微软雅黑", Font.BOLD, 32));
        label.setHorizontalAlignment(JLabel.CENTER);

        this.setTitle(title);
        this.setSize(600, 300);
        this.add(label);
        this.setVisible(true);
    }

    @Override
    @SuppressWarnings({"CallToPrintStackTrace", "BusyWait", "InfiniteLoopStatement"})
    public void run() {
        try {
            while (true) {
                SwingUtilities.invokeLater(() -> {
                    label.setText(ad[index]);
                    index = (index + 1) % ad.length;
                });
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Thread(new Q1("电子广告牌")).start();
    }
}
