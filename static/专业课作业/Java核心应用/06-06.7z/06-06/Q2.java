import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Q2 extends JFrame implements Runnable {
    private final String[] persona = {"付宇峰", "张志华", "吴建平"};
    private final String[] location = {"在教室", "在海里", "在美国"};
    private final String[] event = {"听音乐", "吃草", "放风筝"};
    private final JLabel labelB = new JLabel();
    private final JLabel labelR = new JLabel();
    private final JLabel labelY = new JLabel();
    private final Random random = new Random();

    public Q2() {
        this.setTitle("造句");
        this.setSize(500, 100);

        labelB.setForeground(Color.BLUE);
        labelR.setForeground(Color.RED);
        labelY.setForeground(Color.YELLOW);

        var font = new Font("微软雅黑", Font.BOLD, 32);
        labelB.setFont(font);
        labelR.setFont(font);
        labelY.setFont(font);

        var jPanel = new JPanel();
        jPanel.add(labelB);
        jPanel.add(labelR);
        jPanel.add(labelY);

        this.add(jPanel);

        this.setVisible(true);
    }

    @Override
    @SuppressWarnings({"CallToPrintStackTrace", "BusyWait", "InfiniteLoopStatement"})
    public void run() {
        try {
            while (true) {
                SwingUtilities.invokeLater(() -> {
                    labelB.setText(persona[random.nextInt(persona.length)]);
                    labelR.setText(location[random.nextInt(location.length)]);
                    labelY.setText(event[random.nextInt(event.length)]);
                });
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Thread(new Q2()).start();
    }
}
