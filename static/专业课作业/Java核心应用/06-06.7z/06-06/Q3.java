import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Q3 extends JFrame {
    private final JLabel label;
    private Thread thread;
    private volatile boolean running = true;
    private volatile boolean suspended = false;

    public Q3() {
        label = new JLabel("0", SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.BOLD, 100));
        add(label, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 3));
        addButton(panel, "开始", _ -> startThread());
        addButton(panel, "挂起", _ -> suspendThread());
        addButton(panel, "恢复", _ -> resumeThread());
        addButton(panel, "停止", _ -> stopThread());
        addButton(panel, "状态查询", e -> queryStatus());
        add(panel, BorderLayout.SOUTH);

        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void addButton(Container c, String title, ActionListener listener) {
        JButton button = new JButton(title);
        c.add(button);
        button.addActionListener(listener);
    }

    @SuppressWarnings("BusyWait")
    private void startThread() {
        thread = new Thread(() -> {
            int counter = 0;
            while (running) {
                if (!suspended) {
                    label.setText(String.valueOf(counter));
                    counter = (counter + 1) % 5;
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
        System.out.println("线程开始：" + thread.getState());
    }

    private void suspendThread() {
        suspended = true;
        System.out.println("线程挂起：" + thread.getState());
    }

    private void resumeThread() {
        suspended = false;
        System.out.println("线程恢复：" + thread.getState());
    }

    private void stopThread() {
        running = false;
        System.out.println("线程停止：" + thread.getState());
    }

    private void queryStatus() {
        System.out.println("线程当前状态：" + thread.getState());
    }

    public static void main(String[] args) {
        new Q3();
    }
}
