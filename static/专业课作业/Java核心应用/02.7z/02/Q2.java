import java.util.Scanner;

/**
 * 输入出生年月日，计算生肖和星座
 * 星座算法：
 * 白羊座：03月21日~04月19日（Aries）；
 * 金牛座：04月20日~05月20日（Taurus）；
 * 双子座：05月21日~06月21日（Gemini）；
 * 巨蟹座：06月22日~07月22日（Cancer）；
 * 狮子座：07月23日~08月22日（Leo）；
 * 处女座：08月23日~09月22日（Virgo）；
 * 天秤座：09月23日~10月23日（Libra）；
 * 天蝎座：10月24日~11月22日（Scorpio）；
 * 射手座：11月23日~12月21日（Sagittarius）；
 * 摩羯座：12月22日~01月19日（Capricorn）；
 * 水瓶座：01月20日~02月18日（Aquarius）；
 * 双鱼座：02月19日~03月20日（Pisces）；
 */
public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("请输入出生年份：");
        int year = scanner.nextInt();
        System.out.println("请输入出生月份：");
        int month = scanner.nextInt();
        System.out.println("请输入出生日期：");
        int day = scanner.nextInt();

        // 计算生肖
        String[] zodiacs = {"鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"};
        System.out.println("你的生肖是：" + zodiacs[(year - 4) % 12]);

        // 计算星座
        String[] constellations = {"摩羯座", "水瓶座", "双鱼座", "白羊座", "金牛座", "双子座", "巨蟹座", "狮子座", "处女座", "天秤座", "天蝎座", "射手座", "摩羯座"};
        int[] days = {19, 18, 20, 20, 20, 21, 22, 22, 22, 23, 22, 21};
        System.out.println("你的星座是：" + constellations[(month - (day <= days[month - 1] ? 1 : 0))]);
    }
}
