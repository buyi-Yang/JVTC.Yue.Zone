import java.util.Scanner;

/**
 * 将本班的课表存入二维数组中，输入星期几及第几节课，查出这节是什么课。
 */
public class Q3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[][] schedule = {
                {null, null, null, null},
                {"JavaEE程序设计", "体育与健康", null, null},
                {"安卓应用开发", "Java核心应用", "软件建模", "数据结构"},
                {null, "Java核心应用", "安卓应用开发", "形势与政治"},
                {"JavaEE程序设计", null, null, null}
        };

        // 查询课程
        System.out.println("请输入要查询的星期（1-5）：");
        int day = scanner.nextInt() - 1;
        System.out.println("请输入要查询的课程（1-4）：");
        int lesson = scanner.nextInt() - 1;

        System.out.print("星期" + (day + 1) + "的第" + (lesson + 1) + "节课是：");
        if (schedule[day][lesson] == null) {
            System.out.println("没有课！");
        } else {
            System.out.println(schedule[day][lesson]);
        }
    }
}
