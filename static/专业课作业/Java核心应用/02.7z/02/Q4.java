
import java.util.Scanner;

/**
 * 输入一个整数 n，创建一个 n 行 n 列的二维数组，输入 n*n 个数字存入二维数组，求最外面一圈数字的和。
 */
public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("请输入一个整数n：");
        int n = scanner.nextInt();

        int[][] array = new int[n][n];
        System.out.println("请输入" + (n * n) + "个数字：");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                array[i][j] = scanner.nextInt();
            }
        }

        int sum = 0;
        for (int i = 0; i < n; i++) {
            if (i == 0 || i == n - 1) {
                for (int j = 0; j < n; j++) {
                    sum += array[i][j];
                }
            } else {
                sum += array[i][0] + array[i][n - 1];
            }
        }

        System.out.println("最外面一圈数字的和是：" + sum);
    }
}
