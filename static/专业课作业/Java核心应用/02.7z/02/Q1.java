import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * 输入十个数存入一维数组中，将这十个数存放的顺序首尾交换后，再按顺序输出这十个数。
 */
public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();

        System.out.println("请输入十个数：");
        for (int i = 0; i < 10; i++) {
            numbers.add(scanner.nextInt());
        }

        // 首尾交换
        Collections.reverse(numbers);

        System.out.println("交换后的数组为：");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
}
