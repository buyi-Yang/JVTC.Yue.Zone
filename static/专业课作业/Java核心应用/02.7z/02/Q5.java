import java.util.Scanner;

/**
 * 8 个评委给 10 个选手打分，要求去掉一个最高分和一个最低分后，求每个选手的平均分，找出得分最高的选手的编号。
 */
public class Q5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[][] scores = new double[10][8];
        double[] averages = new double[10];

        // 输入评分
        for (int i = 0; i < 10; i++) {
            System.out.println("请输入选手" + (i + 1) + "的评分：");
            double min = Double.MAX_VALUE, max = Double.MIN_VALUE, sum = 0;
            for (int j = 0; j < 8; j++) {
                scores[i][j] = scanner.nextDouble();
                sum += scores[i][j];
                min = Math.min(min, scores[i][j]);
                max = Math.max(max, scores[i][j]);
            }
            
            // 计算平均分
            averages[i] = (sum - min - max) / 6;
        }

        // 找出得分最高的选手
        int maxIndex = 0;
        for (int i = 1; i < 10; i++) {
            if (averages[i] > averages[maxIndex]) {
                maxIndex = i;
            }
        }

        System.out.println("得分最高的选手是：" + (maxIndex + 1) + "号，平均分是：" + averages[maxIndex]);
    }
}
