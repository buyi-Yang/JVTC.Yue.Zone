import java.util.Random;
import java.util.Scanner;

/**
 * 石头剪刀布游戏：
 * 用户从键盘上输入数字 1、2、3 分别代表石头 剪刀 布，计算机由随机数产生 1、2、3，判定用户和计算机的输赢
 */
public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        while (true) {
            System.out.println("请输入数字 1（石头）、2（剪刀）或 3（布）：");
            int userChoice = 0;
            try {
                userChoice = scanner.nextInt();
                if (userChoice < 1 || userChoice > 3) {
                    throw new Exception("输入错误，只能输入 1、2 或 3");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return;
            }

            int computerChoice = random.nextInt(3) + 1;

            System.out.println(STR."""
            你出的是：\{choiceToString(userChoice)}；计算机出的是：\{choiceToString(computerChoice)}
            """);

            if (userChoice == computerChoice) {
                System.out.println("平局！\n");
            } else if ((userChoice == 1 && computerChoice == 2) ||
                    (userChoice == 2 && computerChoice == 3) ||
                    (userChoice == 3 && computerChoice == 1)) {
                System.out.println("你赢了！\n");
            } else {
                System.out.println("你输了！\n");
            }

        }
    }

    public static String choiceToString(int choice) {
        return switch (choice) {
            case 1 -> "石头";
            case 2 -> "剪刀";
            case 3 -> "布";
            default -> "输入错误";
        };
    }
}
