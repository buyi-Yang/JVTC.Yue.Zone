import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.InputMismatchException;
import java.util.Scanner;

import static java.lang.StringTemplate.STR;

/**
 * 输入全班学生某门课程的成绩，求他们的平均分，学生人数不确定，当输入负数时表示输入过程的结束。
 */
public class Q1 {
    public static void main(String[] args) {
        System.out.println("请输入学生成绩（空格分隔，负数结束）：");

        var sc = new Scanner(System.in);
        var total = BigDecimal.ZERO;
        var count = 0L;

        while (true) {
            try {
                final var in = sc.nextBigDecimal();

                if (in.compareTo(BigDecimal.ZERO) < 0) {
                    System.out.println(STR."""
                    学生成绩平均分（保留两位小数，第三位五舍六入）：
                    \{total.divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_DOWN)}
                    """);
                    break;
                }

                total = total.add(in);
                count++;
            } catch (InputMismatchException e) {
                System.out.println("含有非法输入，请输入数字！");
                break;
            }
        }
    }
}
