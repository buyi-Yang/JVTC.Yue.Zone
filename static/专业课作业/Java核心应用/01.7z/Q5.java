import java.util.Random;
import java.util.Scanner;

/**
 * 程序随机出 10 道 19 以内的加法题，由用户输入答案，每答完一题，程序判断对错，并提示“答对了"，”答错了“。
 * 10 题全部答完，系统提示 10 题中答对的题数以及打错的题数并计算总分。
 */
public class Q5 {
    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        var random = new Random();

        int correctCount = 0;
        int incorrectCount = 0;

        for (int i = 0; i < 10; i++) {
            int num1 = random.nextInt(20);
            int num2 = random.nextInt(20);
            int answer = num1 + num2;

            System.out.println(STR."问题 \{i + 1}: \{num1} + \{num2} = ?");
            System.out.print("你的答案：");
            int userAnswer = scanner.nextInt();

            if (userAnswer == answer) {
                System.out.println("答对了!");
                correctCount++;
            } else {
                System.out.println("答错了!");
                incorrectCount++;
            }
        }

        System.out.println(STR."你一共答对了 \{correctCount} 道题。");
        System.out.println(STR."你一共答错了 \{incorrectCount} 道题。");
        System.out.println(STR."你的总分是 \{correctCount * 10} 分。");
    }
}
