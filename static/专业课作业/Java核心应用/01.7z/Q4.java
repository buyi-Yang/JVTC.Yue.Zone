import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Random;

/**
 * 幸运猜猜猜游戏，游戏机随机给出 0-99 之间的数字，让用户进行数字猜想。
 * 根据用户猜写的数字进行区间判断，是大了还是小了的判定，经过几次猜测和提示后，记录用户猜写的次数。
 * 游戏结束后公布结果。
 */
public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int number = random.nextInt(100);
        int guess;
        int count = 0;

        try {
            do {
                System.out.println("请输入你猜的数字（0-99）：");
                guess = scanner.nextInt();
                count++;

                if (guess > number) System.out.print("你猜的数字大了！");
                else if (guess < number) System.out.print("你猜的数字小了！");
            } while (guess != number);

            System.out.println(STR."恭喜你，你猜中了！你一共猜了 \{count} 次。");
        } catch (InputMismatchException e) {
            System.out.println("输入异常，请输入整数！");
        }
    }
}
