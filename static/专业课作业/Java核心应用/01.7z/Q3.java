import java.util.Scanner;

/**
 * 键盘录入一个字符串，统计该字符串中大写字符，小写字符，数字字符出现的次数，其他字符出现的次数。
 */
public class Q3 {
    public static void main(String[] args) {
        var scanner = new Scanner(System.in);

        //noinspection InfiniteLoopStatement
        while (true) {
            System.out.println("请输入一个字符串（换行结束）：");
            String input = scanner.nextLine();

            int upperCase = 0;
            int lowerCase = 0;
            int digits = 0;
            int others = 0;

            for (char c : input.toCharArray()) {
                if (Character.isUpperCase(c)) upperCase++;
                else if (Character.isLowerCase(c)) lowerCase++;
                else if (Character.isDigit(c)) digits++;
                else others++;
            }

            System.out.println(STR."大写字符数量：\{upperCase}");
            System.out.println(STR."小写字符数量：\{lowerCase}");
            System.out.println(STR."数字字符数量：\{digits}");
            System.out.println(STR."其他字符数量：\{others}");
        }
    }
}
