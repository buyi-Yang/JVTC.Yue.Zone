public class Q1 {
    private static int number = 0;

    @SuppressWarnings({"BusyWait", "CallToPrintStackTrace"})
    public static void main(String[] args) {
        new Thread(() -> {
            while (true) {
                System.out.println(number++);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
