import java.util.Objects;
import java.util.Random;

public class Q3 {
    static class Runner extends Thread {
        private final String name;
        private static final int TOTAL_DISTANCE = 100;
        private static final int RUN_DISTANCE = 10;
        private static final Random RANDOM = new Random();

        public Runner(String name) {
            this.name = name;
        }

        @Override
        @SuppressWarnings("CallToPrintStackTrace")
        public void run() {
            for (int i = RUN_DISTANCE; i <= TOTAL_DISTANCE; i += RUN_DISTANCE) {
                try {
                    Thread.sleep(RANDOM.nextLong(1000));
                    if (name.equals("乌龟")) System.out.print("\t\t\t\t");
                    System.out.println(name + "跑了 " + i + " 米 ");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        new Runner("兔子").start();
        new Runner("乌龟").start();
    }
}
