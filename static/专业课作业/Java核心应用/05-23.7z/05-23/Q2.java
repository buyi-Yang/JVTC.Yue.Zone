import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Q2 {
    static class FruitThread extends Thread {
        private final String fruit;
        private static final int MAX_TIME = 10000;

        public FruitThread(String fruit) {
            this.fruit = fruit;
        }

        @Override
        @SuppressWarnings("CallToPrintStackTrace")
        public void run() {
            Random random = new Random();
            for (int i = 0; i < 5; i++) {
                try {
                    int sleepTime = random.nextInt(MAX_TIME);
                    TimeUnit.MILLISECONDS.sleep(sleepTime);
                    System.out.println("休眠 " + sleepTime + " 毫秒：生产 " + (i+1) + " 个 " + fruit);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        new FruitThread("桃子").start();
        new FruitThread("香蕉").start();
        new FruitThread("苹果").start();
    }
}
