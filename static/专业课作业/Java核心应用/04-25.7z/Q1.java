import java.util.InputMismatchException;

/**
 * 请通过语句编写分别产生 ArithmeticException、NullPointerException、ArrayIndexOutOfBoundsException、NumberFormatException
 * 以及InputMismatchException
 */
@SuppressWarnings("CallToPrintStackTrace")
public class Q1 {
    public static void main(String[] args) {
        try {
            throw new ArithmeticException();
        } catch (ArithmeticException e) {
            e.printStackTrace();
        }

        try {
            throw new NullPointerException();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }


        try {
            throw new ArrayIndexOutOfBoundsException();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        }

        try {
            throw new ArrayIndexOutOfBoundsException();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        }

        try {
            throw new NumberFormatException();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        try {
            throw new InputMismatchException();
        } catch (InputMismatchException e) {
            e.printStackTrace();
        }
    }
}
