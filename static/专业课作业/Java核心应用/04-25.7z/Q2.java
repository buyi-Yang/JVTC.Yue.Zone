import java.util.Scanner;
import java.util.InputMismatchException;

public class Q2 {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("请输入除数:");
            int divisor = scanner.nextInt();

            System.out.println("请输入被除数:");
            int dividend = scanner.nextInt();

            int quotient = dividend / divisor;
            System.out.println("商值是: " + quotient);
        } catch (ArithmeticException e) {
            System.out.println("错误: 除数不能为0");
        } catch (InputMismatchException e) {
            System.out.println("错误: 请输入一个整数");
        } finally {
            System.out.println("计算完成");
        }
    }
}
