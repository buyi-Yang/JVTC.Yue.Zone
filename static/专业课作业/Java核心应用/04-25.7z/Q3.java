public class Q3 {
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("请输入三门课程的成绩");
            return;
        }

        try {
            int totalScore = 0;
            for (int i = 0; i < 3; i++) {
                int score = Integer.parseInt(args[i]);
                if (score < 0 || score > 100) {
                    throw new IllegalArgumentException("成绩必须在0到100之间");
                }
                totalScore += score;
            }
            System.out.println("三门课程的总分是: " + totalScore);
        } catch (NumberFormatException e) {
            System.out.println("无法解析成绩，请确保输入的是数字");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
