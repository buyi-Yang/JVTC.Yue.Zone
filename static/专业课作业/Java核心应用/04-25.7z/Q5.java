class ReservoirOverflowException extends Exception {
    public ReservoirOverflowException(String message) {
        super(message);
    }
}

class Reservoir {
    private int waterLevel;

    public Reservoir(int waterLevel) {
        this.waterLevel = waterLevel;
    }

    public void addWater(int amount) throws ReservoirOverflowException {
        if (this.waterLevel + amount > 100) {
            throw new ReservoirOverflowException("水库水位过高，注意泄洪!");
        } else {
            this.waterLevel += amount;
        }
    }
}

public class Q5 {
    public static void main(String[] args) {
        Reservoir reservoir = new Reservoir(50);
        try {
            reservoir.addWater(60);
        } catch (ReservoirOverflowException e) {
            System.out.println(e.getMessage());
        }
    }
}
