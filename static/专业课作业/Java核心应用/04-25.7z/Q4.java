import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入除数:");
        double divisor = scanner.nextDouble();
        System.out.println("请输入被除数:");
        double dividend = scanner.nextDouble();
        try {
            double result = divide(divisor, dividend);
            System.out.println("商值为: " + result);
        } catch (ArithmeticException e) {
            System.out.println("错误: " + e.getMessage());
        }
    }

    public static double divide(double divisor, double dividend) throws ArithmeticException {
        if (dividend == 0) {
            throw new ArithmeticException("被除数不能为0");
        }
        return divisor / dividend;
    }
}
