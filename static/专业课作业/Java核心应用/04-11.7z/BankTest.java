public class BankTest {
    public static void main(String[] args) {
        Bank bank = new Bank();

        // 用户张三的操作
        bank.openAccount("张三", "123456");
        bank.deposit("张三", 1000);
        bank.withdraw("张三", "123456", 500);
        bank.changePassword("张三", "123456", "654321");

        // 用户李四的操作
        bank.openAccount("李四", "123456");
        bank.deposit("李四", 2000);
        bank.withdraw("李四", "123456", 1000);
        bank.changePassword("李四", "123456", "654321");

        // 用户王五的操作
        bank.openAccount("王五", "123456");
        bank.deposit("王五", 3000);
        bank.withdraw("王五", "123456", 1500);
        bank.changePassword("王五", "123456", "654321");

        // 所有用户离开银行
        bank.leave("张三");
        bank.leave("李四");
        bank.leave("王五");
    }
}
