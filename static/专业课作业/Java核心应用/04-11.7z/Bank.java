import java.util.HashMap;
import java.util.Map;

public class Bank {
    private final Map<String, User> users;

    public Bank() {
        this.users = new HashMap<>();
    }

    public void openAccount(String name, String password) {
        System.out.println(name + "，欢迎来到招商银行，我们将为您办理开户手续。");
        users.put(name, new User(name, password));
    }

    public void deposit(String name, int amount) {
        User user = users.get(name);
        if (user != null) {
            user.deposit(amount);
        } else {
            System.out.println("用户不存在。");
        }
    }

    public void withdraw(String name, String password, int amount) {
        User user = users.get(name);
        if (user != null) {
            user.withdraw(password, amount);
        } else {
            System.out.println("用户不存在。");
        }
    }

    public void changePassword(String name, String oldPassword, String newPassword) {
        User user = users.get(name);
        if (user != null) {
            user.changePassword(oldPassword, newPassword);
        } else {
            System.out.println("用户不存在。");
        }
    }

    public void leave(String name) {
        System.out.println(name + "，感谢您的光临，请携带好随身财物。");
    }

    private static class User {
        private final String name;
        private String password;
        private int balance;

        public User(String name, String password) {
            this.name = name;
            this.password = password;
            this.balance = 0;
        }

        public void deposit(int amount) {
            this.balance += amount;
            System.out.println("存款成功，" + this.name + "的账户余额为：" + this.balance);
        }

        public void withdraw(String password, int amount) {
            if (!this.password.equals(password)) {
                System.out.println("密码错误，取款失败。");
                return;
            }
            if (amount > this.balance) {
                System.out.println("余额不足，取款失败。");
                return;
            }
            this.balance -= amount;
            System.out.println("取款成功，" + this.name + "的账户余额为：" + this.balance);
        }

        public void changePassword(String oldPassword, String newPassword) {
            if (!this.password.equals(oldPassword)) {
                System.out.println("旧密码错误，修改密码失败。");
                return;
            }
            this.password = newPassword;
            System.out.println("密码修改成功。");
        }
    }
}
