import javax.swing.*;
import java.awt.*;

public class Q3 {
    JFrame frame;

    Q3() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        JButton redButton = new JButton("红色");
        redButton.addActionListener(e -> {
            frame.getContentPane().setBackground(Color.RED);
            JOptionPane.showMessageDialog(frame, "背景颜色已更改为红色");
        });

        JButton greenButton = new JButton("绿色");
        greenButton.addActionListener(e -> {
            frame.getContentPane().setBackground(Color.GREEN);
            JOptionPane.showMessageDialog(frame, "背景颜色已更改为绿色");
        });

        JButton blueButton = new JButton("蓝色");
        blueButton.addActionListener(e -> {
            frame.getContentPane().setBackground(Color.BLUE);
            JOptionPane.showMessageDialog(frame, "背景颜色已更改为蓝色");
        });

        frame.setLayout(new FlowLayout());
        frame.add(redButton);
        frame.add(greenButton);
        frame.add(blueButton);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Q3();
    }
}
