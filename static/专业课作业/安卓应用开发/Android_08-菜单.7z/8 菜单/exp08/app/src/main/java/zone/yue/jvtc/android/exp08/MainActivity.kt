package zone.yue.jvtc.android.exp08

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import zone.yue.jvtc.android.exp08.ui.theme.Exp08Theme

@Composable
fun ColorMenuItem(img: Int, text: String, selected: Boolean, onClick: () -> Unit) {
    return DropdownMenuItem(
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(img),
                    contentDescription = text,
                    modifier = Modifier.size(23.dp),
                    tint = Color.Unspecified,
                )
                Text(text, Modifier.padding(horizontal = 23.dp))
                RadioButton(selected, null)
            }
        },
        onClick = onClick,
    )
}

@Preview
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun App() {
    var color by remember { mutableStateOf(Color.Red) }
    var openMenu by remember { mutableStateOf(false) }

    return Scaffold(
        topBar = {
            TopAppBar(title = { Text("bk0602") }, actions = {
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(
                        painter = painterResource(R.drawable.festival),
                        contentDescription = "Festival",
                        tint = Color.Unspecified,
                    )
                }
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(
                        painter = painterResource(id = R.drawable.edit),
                        contentDescription = "Edit",
                        tint = Color.Unspecified,
                    )
                }
                IconButton(onClick = { openMenu = true }) {
                    Icon(Icons.Default.Menu, "Menu")
                }
                DropdownMenu(expanded = openMenu, onDismissRequest = { openMenu = false }) {
                    ColorMenuItem(
                        img = R.drawable.red,
                        text = "红色",
                        selected = color == Color.Red,
                    ) { color = Color.Red }
                    ColorMenuItem(
                        img = R.drawable.green, text = "绿色",
                        selected = color == Color.Green,
                    ) { color = Color.Green }
                    ColorMenuItem(
                        img = R.drawable.blue, text = "蓝色",
                        selected = color == Color.Blue,
                    ) { color = Color.Blue }
                }
            })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {/*TODO*/ }) {
                Icon(Icons.Filled.Email, "Floating action button.")
            }
        }
    ) { p ->
        Column(
            modifier = Modifier
                .padding(p)
                .padding(8.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) { Text(text = "Hello World!", color = color, fontSize = 64.sp) }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Exp08Theme { App() } }
    }
}
