package zone.yue.jvtc.android.exp04

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Scenery(
    val name: String,
    val info: String,
    val imgId: Int,
    val rate: Float,
)

val SceneryData = listOf(
    Scenery("滕王阁", "江南三大名楼之首", R.drawable.twg, 3.5F),
    Scenery("八大山人纪念馆", "集收藏、陈列、研究、宣传为一体", R.drawable.bdsr, 4F),
    Scenery("罕王峰", "青山绿水，风景多彩，盛夏气候凉爽", R.drawable.hwf, 4.5F),
    Scenery("象山森林公园", "避暑、休闲、疗养、度假的最佳场所", R.drawable.xssl, 4F),
    Scenery("西山万寿宫", "江南著名道教宫观和游览胜地", R.drawable.wsg, 3.5F),
    Scenery("梅岭", "山势嵯峨，层峦叠翠，四时秀色，气候宜人", R.drawable.ml, 3F),
)

@Preview
@Composable
fun SceneryItem(scenery: Scenery = SceneryData[0]) {
    Row {
        Image(
            painter = painterResource(scenery.imgId),
            contentDescription = scenery.name,
            modifier = Modifier
                .width(100.dp)
                .height(75.dp)
        )
        Column(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
        ) {
            Text(text = scenery.name, fontSize = 20.sp)
            Text(
                text = scenery.info,
                fontSize = 12.sp,
                color = Color(0xFF0000EE),
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Preview
@Composable
fun SceneryList() {
    Column(
        modifier = Modifier.background(Color(0xFFAABBCC))
    ) {
        SceneryData.forEach {
            SceneryItem(it)
            Divider(thickness = 2.dp, color = Color(0xFFAAAAAA))
        }
    }
}