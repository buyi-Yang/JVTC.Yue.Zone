package zone.yue.jvtc.android.exp04

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.twotone.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import zone.yue.jvtc.android.exp04.ui.theme.Exp04Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Preview
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun App() {
    Exp04Theme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("软件设计赛") }, navigationIcon = {
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(Icons.TwoTone.Person, "Icon")
                    }
                })
            },
        ) {
            Column(Modifier.padding(it)) {
                Text(
                    text = "南昌景点介绍",
                    modifier = Modifier
                        .background(Color(0xFFCCBBAA))
                        .fillMaxWidth()
                        .padding(10.dp),
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center,
                )
                SceneryList()
            }
        }
    }
}
