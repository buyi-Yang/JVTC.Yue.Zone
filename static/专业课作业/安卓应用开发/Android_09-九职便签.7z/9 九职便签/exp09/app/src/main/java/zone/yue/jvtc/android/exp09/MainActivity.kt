package zone.yue.jvtc.android.exp09

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import zone.yue.jvtc.android.exp09.ui.theme.Exp09Theme
import java.io.FileNotFoundException

fun saveFile(context: Context, fileName: String, fileContent: String) {
    if (fileName.isNotBlank()) context.openFileOutput(fileName, Context.MODE_PRIVATE).use {
        it.write(fileContent.toByteArray())
    }
}

fun readFile(context: Context, fileName: String): String {
    try {
        if (fileName.isNotBlank()) context.openFileInput(fileName).bufferedReader().useLines {
            return it.fold("") { some, text -> "$some\n$text" }
        }
        return "请输入文件名！"
    } catch (e: FileNotFoundException) {
        return "文件未找到！"
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun Home(navController: NavController) {
    Scaffold(topBar = { TopAppBar(title = { Text("文件访问") }) }) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(32.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = { navController.navigate("/CreateFile") },
                Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth(),
            ) { Text(text = "创建文件") }
            Button(
                onClick = { navController.navigate("/ReadFile") },
                Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth(),
            ) { Text(text = "读取文件") }
            Button(
                onClick = { navController.navigate("/FileIndex") },
                Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth(),
            ) { Text(text = "读取文件目录") }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun CreateFile(navController: NavController) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("创建文件") },
            navigationIcon = {
                IconButton(onClick = { navController.navigate("/") }) {
                    Icon(Icons.Default.ArrowBack, "Back")
                }
            },
        )
    }) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(8.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val context = LocalContext.current
            var content by remember { mutableStateOf("") }
            var fileName by remember { mutableStateOf("") }

            TextField(
                value = content,
                onValueChange = { content = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(text = "请输入文件内容") },
                minLines = 8,
            )
            TextField(
                value = fileName,
                onValueChange = { fileName = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(text = "请输入文件名") },
                maxLines = 1,
            )
            Button(
                onClick = {
                    saveFile(context, fileName.trim(), content.trim())
                    Toast.makeText(context, "文件已保存！", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .padding(top = 8.dp)
                    .fillMaxWidth()
            ) { Text(text = "保存文件") }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ReadFile(navController: NavController) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("读取文件") },
            navigationIcon = {
                IconButton(onClick = { navController.navigate("/") }) {
                    Icon(Icons.Default.ArrowBack, "Back")
                }
            },
        )
    }) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(8.dp)
                .fillMaxSize(),
        ) {
            val context = LocalContext.current
            var content by remember { mutableStateOf("") }
            var fileName by remember { mutableStateOf("") }

            TextField(
                value = fileName,
                onValueChange = { fileName = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(text = "请输入文件名") },
                maxLines = 1,
            )
            Button(
                onClick = { content = readFile(context, fileName.trim()) },
                Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ) { Text(text = "读取文件") }
            Text(text = content)
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun FileIndex(navController: NavController) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("读取文件") },
            navigationIcon = {
                IconButton(onClick = { navController.navigate("/") }) {
                    Icon(Icons.Default.ArrowBack, "Back")
                }
            },
        )
    }) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(8.dp)
                .fillMaxSize(),
        ) {
            LocalContext.current.fileList().map {
                ListItem(
                    modifier = Modifier.clickable { navController.navigate("/FileContent/$it") },
                    headlineContent = { Text(text = it) },
                )
            }
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun FileContent(
    navController: NavController,
    fileName: String = "[fileName]",
) {
    val content = readFile(LocalContext.current, fileName)

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(fileName) },
            navigationIcon = {
                IconButton(onClick = { navController.navigate("/") }) {
                    Icon(Icons.Default.ArrowBack, "Back")
                }
            },
        )
    }) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(8.dp)
                .fillMaxSize(),
        ) { Text(text = content) }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val navController = rememberNavController()

            Exp09Theme {
                NavHost(navController, startDestination = "/") {
                    composable("/") { Home(navController) }
                    composable("/CreateFile") { CreateFile(navController) }
                    composable("/ReadFile") { ReadFile(navController) }
                    composable("/FileIndex") { FileIndex(navController) }
                    composable(
                        route = "/FileContent/{fileName}",
                        arguments = listOf(navArgument("fileName") { type = NavType.StringType })
                    ) {
                        it.arguments?.getString("fileName")?.let { filename ->
                            FileContent(navController, filename)
                        }
                    }
                }
            }
        }
    }
}