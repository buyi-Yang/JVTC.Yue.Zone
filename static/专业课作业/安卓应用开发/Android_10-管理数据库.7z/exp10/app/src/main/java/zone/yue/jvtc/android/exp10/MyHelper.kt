package zone.yue.jvtc.android.exp10

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class MyHelper(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, name, factory, version) {
    init {
        Log.i("数据库状态", "数据库被声明：数据库名-${name}，版本号-${version}")
    }

    override fun onCreate(db: SQLiteDatabase) {
        Log.i("数据库状态", "创建数据库");
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.i("数据库状态", "升级数据库");
    }

    override fun onOpen(db: SQLiteDatabase?) {
        super.onOpen(db)
        Log.i("数据库状态", "连接数据库");
    }
}
