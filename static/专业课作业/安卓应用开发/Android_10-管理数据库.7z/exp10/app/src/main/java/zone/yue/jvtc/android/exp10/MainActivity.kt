package zone.yue.jvtc.android.exp10

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import zone.yue.jvtc.android.exp10.ui.theme.Exp10Theme

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun Task1() {
    Scaffold(
        topBar = { TopAppBar(title = { Text("数据库创建与连接") }) }
    ) { paddingValue ->
        val context = LocalContext.current
        var dbHelper: MyHelper
        var db: SQLiteDatabase

        Column(
            modifier = Modifier
                .padding(paddingValue)
                .padding(8.dp),
        ) {
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    dbHelper = MyHelper(context, "db_test.db", null, 1)
                    Log.i("数据库状态", "MyHelper对象创建完成")
                    db = dbHelper.writableDatabase
                },
            ) { Text("创建数据库") }
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    dbHelper = MyHelper(context, "db_test.db", null, 2)
                    db = dbHelper.writableDatabase
                },
            ) { Text("升级数据库") }
        }
    }
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Exp10Theme { Task1() }
        }
    }
}