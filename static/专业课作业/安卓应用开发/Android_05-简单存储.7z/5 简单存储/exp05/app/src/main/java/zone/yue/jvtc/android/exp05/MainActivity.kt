package zone.yue.jvtc.android.exp05

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import zone.yue.jvtc.android.exp05.ui.theme.Exp05Theme

val Context.dateStore: DataStore<Preferences> by preferencesDataStore("text")

data class YS(val text: String, val hasBackgroundColor: Boolean) {
    companion object {
        private val textKey = stringSetPreferencesKey("text")
        private val hasBackgroundColorKey = booleanPreferencesKey("hasBackgroundColor")

        suspend fun save(context: Context, ys: YS) = context.dateStore.edit {
            it[textKey] = setOf(ys.text)
            it[hasBackgroundColorKey] = ys.hasBackgroundColor
        }

        suspend fun read(context: Context) = YS(
            context.dateStore.data.first()[textKey].toString(),
            context.dateStore.data.first()[hasBackgroundColorKey] == true
        )
    }
}

@Preview
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun App() {
    val context = LocalContext.current

    var text by remember { mutableStateOf("") }
    var hasBackgroundColor by remember { mutableStateOf(true) }

    var readText by remember { mutableStateOf("") }
    var readHasBackgroundColor by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("简单存储") }) }) { paddingValues ->
        Column(
            Modifier
                .fillMaxWidth()
                .padding(paddingValues)
        ) {
            TextField(text, { text = it }, Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = hasBackgroundColor,
                    onCheckedChange = { hasBackgroundColor = !hasBackgroundColor })
                Text("背景")
            }
            Row(
                modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround
            ) {
                Button(onClick = {
                    CoroutineScope(Dispatchers.IO).launch {
                        YS.save(context, YS(text, hasBackgroundColor))
                        readText = "[写入成功！]"
                    }
                }) { Text("写入") }
                Button(onClick = {
                    CoroutineScope(Dispatchers.IO).launch {
                        val ys = YS.read(context)
                        readText = ys.text
                        readHasBackgroundColor = ys.hasBackgroundColor
                    }
                }) { Text("读取") }
            }
            Text(
                text = readText,
                modifier = Modifier.background(if (readHasBackgroundColor) Color.Gray else Color.White)
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Exp05Theme { App() } }
    }
}