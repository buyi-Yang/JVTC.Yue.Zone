<script setup>
import {reactive} from "vue";

const STUDENTS = reactive([])

function addStudent() {
  STUDENTS.push({
    class: "软件2201",
    name: document.getElementById("name").value,
    sex: document.getElementById("sex").value,
    age: document.getElementById("age").value,
  })
}

function delStudent() {
  STUDENTS.pop()
}
</script>

<template>
  <div>
    <button @click="addStudent">输入学生信息</button>
    <button @click="delStudent">删除学生</button>
  </div>
  <div>
    <label>姓名：<input id="name" type="text"/></label>
    <label>年龄：</label>
    <select id="sex">
      <option value=""></option>
      <option value="男">男</option>
      <option value="女">女</option>
    </select>
    <label>年龄：<input id="age" type="number"></label>
  </div>
  <table>
    <thead>
    <tr>
      <th>班级</th>
      <th>姓名</th>
      <th>性别</th>
      <th>年龄</th>
    </tr>
    </thead>
    <tbody v-for="student in STUDENTS">
    <tr>
      <td>{{student.class}}</td>
      <td>{{student.name}}</td>
      <td>{{student.sex}}</td>
      <td>{{student.age}}</td>
    </tr>
    </tbody>
  </table>
</template>

<style scoped>
table, td, th {border: 1px #000 solid;}
th {padding: 0 16px;}
</style>
