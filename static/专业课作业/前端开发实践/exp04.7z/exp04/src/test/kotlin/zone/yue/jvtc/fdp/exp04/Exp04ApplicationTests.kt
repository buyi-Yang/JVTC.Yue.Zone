package zone.yue.jvtc.fdp.exp04

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Exp04ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
