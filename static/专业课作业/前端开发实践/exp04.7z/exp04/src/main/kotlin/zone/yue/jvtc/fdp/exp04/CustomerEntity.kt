package zone.yue.jvtc.fdp.exp04

import jakarta.persistence.*

@Entity
@Table(name = "customer")
data class CustomerEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customerId", nullable = false)
    val id: Long = -1L,

    @Column(length = 20, nullable = false)
    val name: String = "USERNAME",

    @Column(length = 200, nullable = false)
    val password: String = "PASSWORD",

    @Column(length = 20, nullable = false)
    val city: String = "",
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as CustomerEntity

        return id == other.id
    }

    override fun hashCode(): Int = this.hashCode()
    override fun toString(): String = "CustomerEntity(id=$id, name='$name', password='$password', city='$city')"
}
