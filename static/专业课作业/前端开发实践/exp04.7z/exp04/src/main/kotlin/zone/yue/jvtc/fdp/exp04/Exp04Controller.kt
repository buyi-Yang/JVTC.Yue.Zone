package zone.yue.jvtc.fdp.exp04

import org.slf4j.LoggerFactory
import org.springframework.http.converter.FormHttpMessageConverter
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.*

@Controller
class Exp04Controller(
    private val customerJpaRepository: CustomerJpaRepository,
    private val goodJpaRepository: GoodJpaRepository,
) {
    private val logger = LoggerFactory.getLogger(javaClass)

    data class CustomerForm(val username: String, val password: String)

    @PostMapping("/login")
    @ResponseBody
    fun login(@RequestBody form: CustomerForm): String {
        val user = customerJpaRepository.findByName(form.username) ?: return "用户不存在！"
        if (user.password != form.password) return "密码不匹配！"
        return "登入成功！"
    }

    @PostMapping("/register")
    @ResponseBody
    fun register(@RequestBody form: CustomerForm): String {
        if (customerJpaRepository.existsByName(form.username)) return "用户已存在！"

        logger.info("新用户注册：${form.username}")
        customerJpaRepository.save(
            CustomerEntity(
                name = form.username,
                password = form.password
            )
        )

        return "注册成功！"
    }

    @GetMapping("/store")
    fun store(model: Model): String {
        model.addAttribute("goods", goodJpaRepository.findAll())
        return "store"
    }

    @PostMapping("/buy")
    fun addGood(@RequestParam buyList: Map<String, String>, model: Model): String {
        var goodTotal = 0L
        var goodPrice = 0L

        buyList
            .filterValues { it.isNotEmpty() }
            .forEach {
                goodTotal += it.value.toLong()
                goodPrice += goodJpaRepository.findById(it.key.toLong()).get().price * it.value.toLong()
            }

        model.addAttribute("goodTotal", goodTotal)
        model.addAttribute("goodPrice", goodPrice)

        return "buy"
    }
}
