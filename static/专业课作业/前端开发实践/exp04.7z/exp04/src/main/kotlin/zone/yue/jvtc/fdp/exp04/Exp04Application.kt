package zone.yue.jvtc.fdp.exp04

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import java.math.BigDecimal

@SpringBootApplication
class Exp04Application(
	customerJpaRepository: CustomerJpaRepository,
	goodJpaRepository: GoodJpaRepository,
) {
	init {
		customerJpaRepository.save(CustomerEntity(
			name = "admin",
			password = "admin",
		))

		goodJpaRepository.saveAll(listOf(
			GoodEntity(name = "电饭煲", price = 200),
			GoodEntity(name = "面包", price = 8),
			GoodEntity(name = "自行车", price = 300),
			GoodEntity(name = "飞机", price = 1000000),
			GoodEntity(name = "摩托车", price = 2000),
			GoodEntity(name = "板栗", price = 15),
			GoodEntity(name = "桌子", price = 150),
		))
	}
}

fun main(args: Array<String>) {
	runApplication<Exp04Application>(*args)
}
